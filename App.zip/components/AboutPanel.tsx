import React from "react";

type AboutPanelProps = {
  showAbout: boolean;
  setShowAbout: (value: boolean) => void;
};

export default function AboutPanel({ showAbout, setShowAbout }: AboutPanelProps) {
  return (
    <div className="fixed bottom-4 right-4 z-40">
      <div className="relative">
        <button
          type="button"
          onClick={() => setShowAbout(!showAbout)}
          className="rounded-full border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 shadow-lg hover:bg-slate-50"
        >
          About
        </button>

        {showAbout && (
          <div className="absolute bottom-11 right-0 w-72 rounded-2xl border border-slate-200 bg-white p-4 text-sm shadow-2xl">
            <div className="mb-1 font-semibold text-slate-800">
              Easy English Channel Voice Generator
            </div>
            <div className="space-y-1 text-slate-600">
              <div>Version: 2.0.0</div>
              <div>Create by Trần Văn Thắng</div>
            </div>

            <button
              type="button"
              onClick={() => setShowAbout(false)}
              className="mt-3 rounded-lg border border-slate-300 px-3 py-1 text-xs text-slate-700 hover:bg-slate-50"
            >
              Đóng
            </button>
          </div>
        )}
      </div>
    </div>
  );
}