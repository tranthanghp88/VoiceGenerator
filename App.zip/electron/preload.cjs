const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("electronAPI", {
  isDesktop: true,
  platform: process.platform,

  selectFolder: () => ipcRenderer.invoke("dialog:select-folder"),

  saveAudioFile: (payload) => ipcRenderer.invoke("fs:save-audio-file", payload),
  listAudioFiles: (payload) => ipcRenderer.invoke("fs:list-audio-files", payload),
  readAudioFile: (payload) => ipcRenderer.invoke("fs:read-audio-file", payload)
});