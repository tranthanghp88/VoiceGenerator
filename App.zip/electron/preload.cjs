const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("electronAPI", {
  isDesktop: true,
  platform: process.platform,

  selectFolder: () => ipcRenderer.invoke("dialog:select-folder"),
  selectAudioFile: () => ipcRenderer.invoke("dialog:select-audio-file"),
  selectAudioFiles: () => ipcRenderer.invoke("dialog:select-audio-files"),
  selectImageFile: () => ipcRenderer.invoke("dialog:select-image-file"),

  readAudioFile: (payload) => ipcRenderer.invoke("file:read-audio-file", payload),
  saveAudioFile: (payload) => ipcRenderer.invoke("file:save-audio", payload),
  listAudioFiles: (payload) => ipcRenderer.invoke("file:list-audio-files", payload),
  listBgmAssets: () => ipcRenderer.invoke("file:list-bgm-assets"),
  importBgmAssets: (payload) => ipcRenderer.invoke("file:import-bgm-assets", payload),
  deleteBgmAsset: (payload) => ipcRenderer.invoke("file:delete-bgm-asset", payload),

  convertWaveformVideo: (payload) => ipcRenderer.invoke("file:convert-waveform-video", payload),
  composeFinalMedia: (payload) => ipcRenderer.invoke("file:compose-final-media", payload)
});
